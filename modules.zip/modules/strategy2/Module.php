<?php

namespace app\modules\strategy2;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\strategy2\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
