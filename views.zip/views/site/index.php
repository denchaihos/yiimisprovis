<?php

/* @var $this yii\web\View */

$this->title = 'ระบบข้อมูลสุขภาพและบริหารจัดการ 43 แฟ้ม';
?>
<div class="site-index">

    <div class="col-lg-12 site-background">
		<div class="jumbotron">
			<h2>Management Information System</h2>
			<p class="lead">เขตสุขภาพที่ 10</p>
		</div>
	</div>
</div>
